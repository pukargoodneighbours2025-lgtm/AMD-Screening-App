import streamlit as st
import tempfile
import os
import zipfile
from PIL import Image
import io
import base64
from datetime import datetime
from utils.image_processing import validate_image_quality, process_image
from utils.ai_simulation import simulate_amd_prediction

st.set_page_config(page_title="Upload Images", page_icon="📤", layout="wide")

def main():
    st.title("📤 Add Images")
    
    # Navigation
    col1, col2 = st.columns([1, 4])
    with col1:
        if st.button("← Back to Dashboard"):
            st.switch_page("app.py")
    
    st.markdown("---")
    
    # Upload options
    st.subheader("Choose Upload Method")
    
    tab1, tab2, tab3 = st.tabs(["📁 Upload Files", "📷 Camera Capture", "📦 Upload ZIP/Folder"])
    
    with tab1:
        st.markdown("**Drag images here or click to browse — .jpg .png**")
        st.caption("💡 **Recommended:** center macula, avoid glare")
        
        uploaded_files = st.file_uploader(
            "Choose image files",
            type=['jpg', 'jpeg', 'png'],
            accept_multiple_files=True,
            label_visibility="collapsed"
        )
        
        if uploaded_files:
            process_uploaded_files(uploaded_files)
    
    with tab2:
        st.markdown("**📷 Camera Capture**")
        st.info("🔧 Camera capture functionality would integrate with device camera API in production")
        
        # Simulated camera interface
        st.markdown("""
        **Mobile Camera UI Features:**
        - Full-screen capture mode
        - Macula guide circle overlay
        - Live focus/blur indicator
        - Touch targets ≥ 44x44 px
        """)
        
        if st.button("🎥 Open Camera Interface"):
            st.success("📱 Camera interface would open here in production")
    
    with tab3:
        st.markdown("**Upload ZIP file containing images**")
        
        zip_file = st.file_uploader(
            "Choose ZIP file",
            type=['zip'],
            label_visibility="collapsed"
        )
        
        if zip_file:
            process_zip_file(zip_file)
    
    # Display processing results
    if 'upload_results' in st.session_state and st.session_state.upload_results:
        st.markdown("---")
        st.subheader("📋 Processing Results")
        
        for result in st.session_state.upload_results:
            with st.expander(f"📸 {result['filename']}", expanded=True):
                col1, col2 = st.columns([1, 2])
                
                with col1:
                    if result['image']:
                        st.image(result['image'], caption=result['filename'], width=200)
                
                with col2:
                    if result['status'] == 'success':
                        st.success("✅ Successfully processed")
                        
                        # Display prediction results
                        prediction = result['prediction']
                        confidence = result['confidence']
                        
                        # Prediction display with color coding
                        if prediction == 'ARMD':
                            st.markdown(f"**Prediction:** <span style='color: #D64545;'>🔴 {prediction}</span>", unsafe_allow_html=True)
                        else:
                            st.markdown(f"**Prediction:** <span style='color: #42A784;'>🟢 {prediction}</span>", unsafe_allow_html=True)
                        
                        st.metric("Confidence", f"{confidence:.1f}%")
                        
                        # Referral recommendation
                        referral = result['referral']
                        if referral == 'Urgent':
                            st.error(f"🚨 **Referral:** {referral}")
                        elif referral == 'Routine':
                            st.warning(f"⚠️ **Referral:** {referral}")
                        else:
                            st.success(f"✅ **Referral:** {referral}")
                        
                        # Quality flags
                        qc_flags = result['qc_flags']
                        st.markdown("**Quality Assessment:**")
                        for flag, status in qc_flags.items():
                            icon = "✅" if status else "❌"
                            st.markdown(f"- {icon} {flag}")
                    
                    else:
                        st.error(f"❌ Failed: {result['error']}")
        
        # Batch actions
        st.markdown("---")
        col1, col2, col3 = st.columns(3)
        
        with col1:
            if st.button("📊 View in Batch Results"):
                st.switch_page("pages/2_Batch_Results.py")
        
        with col2:
            if st.button("📄 Generate Report"):
                st.success("📋 Report generation started")
        
        with col3:
            if st.button("💾 Export All"):
                export_all_results()

def export_all_results():
    """Export all processed images to CSV"""
    # Check if we have any processed images
    if 'processed_images' not in st.session_state or not st.session_state.processed_images:
        st.warning("⚠️ No processed images available for export.")
        return
    
    processed_images = st.session_state.processed_images
    
    # Generate CSV export using the utility function
    from utils.pdf_generator import export_csv_report
    from datetime import datetime
    
    try:
        csv_data = export_csv_report(processed_images)
        
        # Generate filename with timestamp
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"amd_all_results_{timestamp}.csv"
        
        # Show download button
        st.download_button(
            label="💾 Download All Results (CSV)",
            data=csv_data,
            file_name=filename,
            mime="text/csv",
            use_container_width=True
        )
        
        st.success(f"📦 Export ready! {len(processed_images)} images exported to CSV.")
        
    except Exception as e:
        st.error(f"❌ Export failed: {str(e)}")

def process_uploaded_files(uploaded_files):
    """Process uploaded image files"""
    if 'upload_results' not in st.session_state:
        st.session_state.upload_results = []
    
    progress_bar = st.progress(0)
    status_text = st.empty()
    
    for i, uploaded_file in enumerate(uploaded_files):
        status_text.text(f"Processing {uploaded_file.name}...")
        progress_bar.progress((i + 1) / len(uploaded_files))
        
        try:
            # Load and validate image
            image = Image.open(uploaded_file)
            
            # Quality validation
            qc_flags = validate_image_quality(image)
            
            # AI prediction simulation
            prediction_result = simulate_amd_prediction(image)
            
            # Store result
            result = {
                'filename': uploaded_file.name,
                'image': image,
                'status': 'success',
                'prediction': prediction_result['prediction'],
                'confidence': prediction_result['confidence'],
                'referral': prediction_result['referral'],
                'qc_flags': qc_flags,
                'upload_time': datetime.now(),
                'notes': '',
                'reviewed': False
            }
            
            st.session_state.upload_results.append(result)
            
            # Also add to processed images for dashboard
            if 'processed_images' not in st.session_state:
                st.session_state.processed_images = []
            
            st.session_state.processed_images.append(result)
            
        except Exception as e:
            # Handle processing errors
            result = {
                'filename': uploaded_file.name,
                'image': None,
                'status': 'error',
                'error': str(e)
            }
            st.session_state.upload_results.append(result)
    
    status_text.text("✅ Processing complete!")
    progress_bar.progress(1.0)

def process_zip_file(zip_file):
    """Process uploaded ZIP file containing images"""
    try:
        with zipfile.ZipFile(zip_file, 'r') as zip_ref:
            # Extract image files
            image_files = [f for f in zip_ref.namelist() 
                          if f.lower().endswith(('.jpg', '.jpeg', '.png'))]
            
            if not image_files:
                st.error("❌ No valid image files found in ZIP")
                return
            
            st.info(f"📦 Found {len(image_files)} images in ZIP file")
            
            if 'upload_results' not in st.session_state:
                st.session_state.upload_results = []
            
            progress_bar = st.progress(0)
            status_text = st.empty()
            
            for i, file_path in enumerate(image_files):
                status_text.text(f"Processing {os.path.basename(file_path)}...")
                progress_bar.progress((i + 1) / len(image_files))
                
                try:
                    # Extract and process image
                    with zip_ref.open(file_path) as img_file:
                        image = Image.open(io.BytesIO(img_file.read()))
                        
                        # Quality validation
                        qc_flags = validate_image_quality(image)
                        
                        # AI prediction simulation
                        prediction_result = simulate_amd_prediction(image)
                        
                        # Store result
                        result = {
                            'filename': os.path.basename(file_path),
                            'image': image,
                            'status': 'success',
                            'prediction': prediction_result['prediction'],
                            'confidence': prediction_result['confidence'],
                            'referral': prediction_result['referral'],
                            'qc_flags': qc_flags,
                            'upload_time': datetime.now(),
                            'notes': '',
                            'reviewed': False
                        }
                        
                        st.session_state.upload_results.append(result)
                        
                        # Also add to processed images for dashboard
                        if 'processed_images' not in st.session_state:
                            st.session_state.processed_images = []
                        
                        st.session_state.processed_images.append(result)
                
                except Exception as e:
                    result = {
                        'filename': os.path.basename(file_path),
                        'image': None,
                        'status': 'error',
                        'error': str(e)
                    }
                    st.session_state.upload_results.append(result)
            
            status_text.text("✅ ZIP processing complete!")
            progress_bar.progress(1.0)
            
    except Exception as e:
        st.error(f"❌ Error processing ZIP file: {str(e)}")

if __name__ == "__main__":
    main()
