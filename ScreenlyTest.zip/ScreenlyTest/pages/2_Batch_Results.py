import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime
import plotly.express as px
from utils.pdf_generator import generate_batch_report

st.set_page_config(page_title="Batch Results", page_icon="📊", layout="wide")

def main():
    st.title("📊 Batch Results")
    
    # Navigation
    col1, col2 = st.columns([1, 4])
    with col1:
        if st.button("← Back to Dashboard"):
            st.switch_page("app.py")
    
    # Check if we have processed images
    if 'processed_images' not in st.session_state or not st.session_state.processed_images:
        st.info("📂 No processed images found. Upload images first.")
        if st.button("📤 Upload Images"):
            st.switch_page("pages/1_Upload_Images.py")
        return
    
    st.markdown("---")
    
    # Filter controls
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        filter_prediction = st.selectbox(
            "🔍 Filter by Prediction",
            options=["All", "ARMD", "Normal"],
            key="filter_prediction"
        )
    
    with col2:
        filter_referral = st.selectbox(
            "🏥 Filter by Referral",
            options=["All", "Urgent", "Routine", "No Referral"],
            key="filter_referral"
        )
    
    with col3:
        filter_qc = st.selectbox(
            "✅ Quality Control",
            options=["All", "QC Passed", "QC Failed"],
            key="filter_qc"
        )
    
    with col4:
        filter_reviewed = st.selectbox(
            "👨‍⚕️ Review Status",
            options=["All", "Reviewed", "Pending Review"],
            key="filter_reviewed"
        )
    
    # Apply filters
    filtered_data, original_indices = apply_filters(st.session_state.processed_images)
    
    if not filtered_data:
        st.warning("⚠️ No images match the current filters.")
        return
    
    # Summary metrics
    st.subheader("📈 Summary")
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Total Images", len(filtered_data))
    
    with col2:
        armd_count = len([img for img in filtered_data if img['prediction'] == 'ARMD'])
        st.metric("ARMD Detected", armd_count)
    
    with col3:
        urgent_count = len([img for img in filtered_data if img['referral'] == 'Urgent'])
        st.metric("Urgent Referrals", urgent_count)
    
    with col4:
        avg_confidence = np.mean([img['confidence'] for img in filtered_data])
        st.metric("Avg Confidence", f"{avg_confidence:.1f}%")
    
    # Bulk actions
    st.markdown("---")
    st.subheader("🔧 Bulk Actions")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        if st.button("📄 Export Selected", use_container_width=True):
            export_selected_results()
    
    with col2:
        if st.button("✅ Mark Reviewed", use_container_width=True):
            mark_selected_reviewed()
    
    with col3:
        if st.button("🏥 Send Referral", use_container_width=True):
            send_referrals()
    
    with col4:
        if st.button("📊 Generate Report", use_container_width=True):
            generate_batch_report_action()
    
    # Results table
    st.markdown("---")
    st.subheader("📋 Results Table")
    
    # Convert to DataFrame for display
    df = create_results_dataframe(filtered_data, original_indices)
    
    # Column configuration for better display
    column_config = {
        "Select": st.column_config.CheckboxColumn(
            "Select",
            help="Select for bulk actions",
            default=False,
        ),
        "Image": st.column_config.ImageColumn(
            "Image", 
            help="Thumbnail preview"
        ),
        "Prediction": st.column_config.TextColumn(
            "Prediction",
            help="AI model prediction (* = overridden)"
        ),
        "Confidence": st.column_config.ProgressColumn(
            "Confidence (%)",
            help="Model confidence score",
            min_value=0,
            max_value=100,
        ),
        "Referral": st.column_config.TextColumn(
            "Referral",
            help="Referral recommendation"
        ),
        "QC Status": st.column_config.TextColumn(
            "QC Status",
            help="Quality control status"
        ),
        "Override": st.column_config.TextColumn(
            "Override",
            help="Manual override indicator"
        ),
        "Notes": st.column_config.TextColumn(
            "Notes",
            help="Clinician notes indicator"
        ),
        "Actions": st.column_config.TextColumn(
            "Actions",
            help="Available actions"
        )
    }
    
    edited_df = st.data_editor(
        df,
        column_config=column_config,
        disabled=["Image", "Prediction", "Confidence", "Referral", "QC Status", "Override", "Notes", "Actions"],
        hide_index=True,
        use_container_width=True,
        column_order=["Select", "Patient/ID", "Image", "Prediction", "Confidence", "Referral", "QC Status", "Override", "Notes", "Reviewed", "Actions"]
    )
    
    # Store the edited dataframe and selection data in session state
    st.session_state.last_edited_df = edited_df
    st.session_state.filtered_data = filtered_data
    st.session_state.original_indices = original_indices
    
    # Handle row selection and actions
    selected_rows = edited_df[edited_df["Select"] == True]
    
    if len(selected_rows) > 0:
        st.info(f"📝 {len(selected_rows)} images selected")
        
        # Individual actions for selected items
        for idx, row in selected_rows.iterrows():
            original_idx = int(row['original_index'])  # Get the original index
            with st.expander(f"🔍 {row['Patient/ID']}", expanded=False):
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    if st.button(f"🔍 View Details", key=f"view_{original_idx}"):
                        st.session_state.selected_image_idx = original_idx
                        st.switch_page("pages/3_Image_Viewer.py")
                
                with col2:
                    if st.button(f"📝 Add Notes", key=f"notes_{original_idx}"):
                        add_notes_modal(original_idx)
                
                with col3:
                    if st.button(f"🔄 Override", key=f"override_{original_idx}"):
                        override_prediction_modal(original_idx)

def apply_filters(data):
    """Apply selected filters to the data, returning (filtered_data, original_indices)"""
    filtered_data = []
    original_indices = []
    
    for i, img in enumerate(data):
        include = True
        
        # Filter by prediction
        if st.session_state.filter_prediction != "All":
            if img['prediction'] != st.session_state.filter_prediction:
                include = False
        
        # Filter by referral
        if st.session_state.filter_referral != "All":
            if img['referral'] != st.session_state.filter_referral:
                include = False
        
        # Filter by QC status
        if st.session_state.filter_qc == "QC Passed":
            if not all(img['qc_flags'].values()):
                include = False
        elif st.session_state.filter_qc == "QC Failed":
            if all(img['qc_flags'].values()):
                include = False
        
        # Filter by review status
        if st.session_state.filter_reviewed == "Reviewed":
            if not img.get('reviewed', False):
                include = False
        elif st.session_state.filter_reviewed == "Pending Review":
            if img.get('reviewed', False):
                include = False
        
        if include:
            filtered_data.append(img)
            original_indices.append(i)
    
    return filtered_data, original_indices

def create_results_dataframe(data, original_indices):
    """Create DataFrame for display in the results table"""
    rows = []
    
    for i, (img, orig_idx) in enumerate(zip(data, original_indices)):
        # Generate patient ID if not exists
        patient_id = img.get('patient_id', f"PAT-{orig_idx+1:04d}")
        
        # QC status
        qc_passed = all(img['qc_flags'].values())
        qc_status = "✅ Passed" if qc_passed else "❌ Failed"
        
        # Referral with color coding
        referral = img['referral']
        if referral == 'Urgent':
            referral_display = "🚨 Urgent"
        elif referral == 'Routine':
            referral_display = "⚠️ Routine"
        else:
            referral_display = "✅ No Referral"
        
        # Review status
        reviewed = "✅" if img.get('reviewed', False) else "⏳"
        
        # Override status and notes
        override_status = "🔄" if img.get('overridden', False) else ""
        notes_preview = "📝" if img.get('notes', '') else ""
        
        # Prediction display with override indicator
        prediction_display = img['prediction']
        if img.get('overridden', False):
            prediction_display = f"🔄 {prediction_display}*"
        
        row = {
            "Select": False,
            "Patient/ID": patient_id,
            "Image": img['image'] if img.get('image') else None,
            "Prediction": prediction_display,
            "Confidence": img['confidence'],
            "Referral": referral_display,
            "QC Status": qc_status,
            "Override": override_status,
            "Notes": notes_preview,
            "Reviewed": reviewed,
            "Actions": "View • Edit • Export",
            "original_index": orig_idx  # Hidden column for mapping
        }
        rows.append(row)
    
    return pd.DataFrame(rows)

def export_selected_results():
    """Export selected results"""
    # Check if we have the edited dataframe in session state
    if 'last_edited_df' not in st.session_state:
        st.error("❌ No selection data available. Please make a selection first.")
        return
    
    edited_df = st.session_state.last_edited_df
    selected_rows = edited_df[edited_df["Select"] == True]
    
    if len(selected_rows) == 0:
        st.warning("⚠️ No images selected for export.")
        return
    
    # Extract selected image data using original indices
    selected_images = []
    for idx, row in selected_rows.iterrows():
        original_idx = int(row['original_index'])
        if original_idx < len(st.session_state.processed_images):
            selected_images.append(st.session_state.processed_images[original_idx])
    
    if not selected_images:
        st.error("❌ Unable to retrieve selected image data.")
        return
    
    # Generate CSV export
    from utils.pdf_generator import export_csv_report
    from datetime import datetime
    
    try:
        csv_data = export_csv_report(selected_images)
        
        # Generate filename with timestamp
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"amd_selected_results_{timestamp}.csv"
        
        # Show download button
        st.download_button(
            label="💾 Download Selected Results (CSV)",
            data=csv_data,
            file_name=filename,
            mime="text/csv",
            use_container_width=True
        )
        
        st.success(f"📦 Export ready! {len(selected_images)} images exported to CSV.")
        
    except Exception as e:
        st.error(f"❌ Export failed: {str(e)}")

def mark_selected_reviewed():
    """Mark selected images as reviewed"""
    st.success("✅ Selected images marked as reviewed")

def send_referrals():
    """Send referrals for selected urgent cases"""
    st.success("🏥 Referrals queued for processing")

def generate_batch_report_action():
    """Generate batch report"""
    # Check if we have filtered data
    if 'filtered_data' not in st.session_state:
        st.error("❌ No data available for report generation.")
        return
    
    filtered_data = st.session_state.filtered_data
    
    if not filtered_data:
        st.warning("⚠️ No images match current filters for report generation.")
        return
    
    # Calculate summary statistics
    total_images = len(filtered_data)
    amd_cases = len([img for img in filtered_data if img['prediction'] == 'ARMD'])
    normal_cases = len([img for img in filtered_data if img['prediction'] == 'Normal'])
    urgent_referrals = len([img for img in filtered_data if img['referral'] == 'Urgent'])
    avg_confidence = np.mean([img['confidence'] for img in filtered_data])
    
    # QC pass rate calculation
    qc_passed = sum(1 for img in filtered_data if all(img.get('qc_flags', {}).values()))
    qc_pass_rate = (qc_passed / total_images * 100) if total_images > 0 else 0
    
    summary_stats = {
        'total_images': total_images,
        'amd_cases': amd_cases,
        'normal_cases': normal_cases,
        'urgent_referrals': urgent_referrals,
        'avg_confidence': avg_confidence,
        'qc_pass_rate': qc_pass_rate
    }
    
    # Generate PDF report
    from utils.pdf_generator import generate_batch_report
    from datetime import datetime
    
    try:
        pdf_data = generate_batch_report(filtered_data, summary_stats)
        
        # Generate filename with timestamp
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"amd_batch_report_{timestamp}.pdf"
        
        # Show download button
        st.download_button(
            label="📄 Download Batch Report (PDF)",
            data=pdf_data,
            file_name=filename,
            mime="application/pdf",
            use_container_width=True
        )
        
        st.success(f"📊 Batch report ready! {total_images} images included.")
        
        # Show summary statistics
        with st.expander("📈 Report Summary", expanded=True):
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("AMD Cases", amd_cases)
                st.metric("Normal Cases", normal_cases)
            with col2:
                st.metric("Urgent Referrals", urgent_referrals)
                st.metric("Avg Confidence", f"{avg_confidence:.1f}%")
            with col3:
                st.metric("QC Pass Rate", f"{qc_pass_rate:.1f}%")
                st.metric("Total Images", total_images)
        
    except Exception as e:
        st.error(f"❌ Report generation failed: {str(e)}")

def add_notes_modal(idx):
    """Add notes to specific image"""
    current_notes = st.session_state.processed_images[idx].get('notes', '')
    
    with st.expander("📝 Add/Edit Clinician Notes", expanded=True):
        notes_text = st.text_area(
            "Notes:",
            value=current_notes,
            key=f"notes_text_{idx}",
            height=100,
            help="Enter clinical observations, recommendations, or other relevant notes"
        )
        
        col1, col2 = st.columns(2)
        
        with col1:
            if st.button("💾 Save Notes", key=f"save_notes_{idx}"):
                st.session_state.processed_images[idx]['notes'] = notes_text
                st.success("📝 Notes saved successfully")
                st.rerun()
        
        with col2:
            if st.button("❌ Clear Notes", key=f"clear_notes_{idx}"):
                st.session_state.processed_images[idx]['notes'] = ''
                st.success("📝 Notes cleared")
                st.rerun()

def override_prediction_modal(idx):
    """Override prediction for specific image"""
    current_image = st.session_state.processed_images[idx]
    current_pred = current_image['prediction']
    
    with st.expander("🔄 Override Model Prediction", expanded=True):
        st.write(f"**Current Prediction:** {current_pred} ({current_image['confidence']:.1f}%)")
        
        # Get current override values if they exist
        current_override_reason = current_image.get('override_reason', 'Image artifact')
        current_override_notes = current_image.get('override_notes', '')
        
        new_prediction = st.selectbox(
            "New Prediction:",
            options=["ARMD", "Normal"],
            index=0 if current_pred == "ARMD" else 1,
            key=f"override_pred_{idx}",
            help="Select the correct diagnosis"
        )
        
        override_reason = st.selectbox(
            "Reason for Override:",
            options=["Image artifact", "Other disease", "Label error", "Clinical judgment", "Other"],
            index=0,  # Default to first option
            key=f"override_reason_{idx}",
            help="Why is the AI prediction being overridden?"
        )
        
        additional_notes = st.text_area(
            "Additional Notes:",
            value=current_override_notes,
            key=f"override_notes_{idx}",
            height=80,
            help="Optional additional details about the override decision"
        )
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            if st.button("💾 Save Override", key=f"save_override_{idx}"):
                # Store original prediction if not already overridden
                if not current_image.get('overridden', False):
                    st.session_state.processed_images[idx]['original_prediction'] = current_pred
                    st.session_state.processed_images[idx]['original_confidence'] = current_image['confidence']
                
                # Update with override values
                st.session_state.processed_images[idx]['prediction'] = new_prediction
                st.session_state.processed_images[idx]['override_reason'] = override_reason
                st.session_state.processed_images[idx]['override_notes'] = additional_notes
                st.session_state.processed_images[idx]['overridden'] = True
                
                # Update referral recommendation based on new prediction
                if new_prediction == 'ARMD':
                    st.session_state.processed_images[idx]['referral'] = 'Urgent'
                else:
                    st.session_state.processed_images[idx]['referral'] = 'No Referral'
                
                st.success("🔄 Prediction override saved successfully!")
                st.rerun()
        
        with col2:
            if current_image.get('overridden', False):
                if st.button("↩️ Restore Original", key=f"restore_override_{idx}"):
                    # Restore original prediction
                    original_pred = current_image.get('original_prediction', current_pred)
                    original_conf = current_image.get('original_confidence', current_image['confidence'])
                    
                    st.session_state.processed_images[idx]['prediction'] = original_pred
                    st.session_state.processed_images[idx]['confidence'] = original_conf
                    st.session_state.processed_images[idx]['overridden'] = False
                    
                    # Remove override-specific fields
                    for key in ['override_reason', 'override_notes', 'original_prediction', 'original_confidence']:
                        st.session_state.processed_images[idx].pop(key, None)
                    
                    # Restore original referral
                    if original_pred == 'ARMD':
                        st.session_state.processed_images[idx]['referral'] = 'Urgent'
                    else:
                        st.session_state.processed_images[idx]['referral'] = 'No Referral'
                    
                    st.success("↩️ Original prediction restored")
                    st.rerun()
        
        with col3:
            if st.button("❌ Cancel", key=f"cancel_override_{idx}"):
                st.info("❌ Override cancelled")

if __name__ == "__main__":
    main()
