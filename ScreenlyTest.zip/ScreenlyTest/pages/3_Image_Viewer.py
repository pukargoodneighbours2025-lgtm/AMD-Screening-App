import streamlit as st
import numpy as np
from PIL import Image, ImageEnhance
import plotly.express as px
import plotly.graph_objects as go
from utils.explainability import generate_gradcam, generate_guided_gradcam, generate_integrated_gradients

st.set_page_config(page_title="Image Viewer", page_icon="🔍", layout="wide")

def main():
    st.title("🔍 Single Image Viewer")
    
    # Navigation
    col1, col2 = st.columns([1, 4])
    with col1:
        if st.button("← Back to Results"):
            st.switch_page("pages/2_Batch_Results.py")
    
    # Check if we have an image selected
    if 'selected_image_idx' not in st.session_state:
        st.warning("⚠️ No image selected. Please select an image from the batch results.")
        if st.button("📊 Go to Batch Results"):
            st.switch_page("pages/2_Batch_Results.py")
        return
    
    if 'processed_images' not in st.session_state or not st.session_state.processed_images:
        st.error("❌ No processed images found.")
        return
    
    # Get selected image
    idx = st.session_state.selected_image_idx
    if idx >= len(st.session_state.processed_images):
        st.error("❌ Invalid image selection.")
        return
    
    image_data = st.session_state.processed_images[idx]
    
    # Header with prediction info
    prediction = image_data['prediction']
    confidence = image_data['confidence']
    filename = image_data['filename']
    
    # Color-coded prediction header
    if prediction == 'ARMD':
        header_color = "#D64545"
        icon = "🔴"
    else:
        header_color = "#42A784"
        icon = "🟢"
    
    # Use safe text display instead of HTML injection
    import html
    safe_filename = html.escape(filename)
    st.markdown(f"""
    <h3 style='color: {header_color};'>
    {icon} Image: {safe_filename} — Predicted: {prediction} ({confidence:.1f}%)
    </h3>
    """, unsafe_allow_html=True)
    
    st.markdown("---")
    
    # Main layout: Image viewer + Controls + Right panel
    col1, col2 = st.columns([3, 1])
    
    with col1:
        # Image viewer tabs
        tab1, tab2 = st.tabs(["🖼️ Image Viewer", "🔬 Explainability"])
        
        with tab1:
            display_image_viewer(image_data)
        
        with tab2:
            display_explainability_panel(image_data)
    
    with col2:
        # Right panel with controls and info
        display_right_panel(image_data, idx)

def display_image_viewer(image_data):
    """Display the main image viewer with controls"""
    image = image_data['image']
    
    if image is None:
        st.error("❌ Image not available")
        return
    
    # Image controls
    st.subheader("🎛️ Image Controls")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        zoom = st.slider("🔍 Zoom", min_value=50, max_value=200, value=100, step=10)
    
    with col2:
        brightness = st.slider("💡 Brightness", min_value=50, max_value=150, value=100, step=5)
    
    with col3:
        contrast = st.slider("🌗 Contrast", min_value=50, max_value=150, value=100, step=5)
    
    # Apply image adjustments
    processed_image = image.copy()
    
    # Apply brightness and contrast
    if brightness != 100:
        enhancer = ImageEnhance.Brightness(processed_image)
        processed_image = enhancer.enhance(brightness / 100.0)
    
    if contrast != 100:
        enhancer = ImageEnhance.Contrast(processed_image)
        processed_image = enhancer.enhance(contrast / 100.0)
    
    # Calculate display size based on zoom
    original_width, original_height = processed_image.size
    display_width = int(original_width * zoom / 100)
    
    # Display the image
    st.image(processed_image, width=display_width, caption=f"Zoom: {zoom}%")
    
    # Image manipulation buttons
    st.subheader("🔧 Image Tools")
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        if st.button("↻ Rotate Left"):
            st.info("🔄 Rotate functionality")
    
    with col2:
        if st.button("↺ Rotate Right"):
            st.info("🔄 Rotate functionality")
    
    with col3:
        if st.button("⟷ Flip Horizontal"):
            st.info("🔄 Flip functionality")
    
    with col4:
        if st.button("⟷ Flip Vertical"):
            st.info("🔄 Flip functionality")

def display_explainability_panel(image_data):
    """Display explainability visualizations"""
    st.subheader("🔬 AI Explainability")
    
    # Explainability method selection
    method = st.selectbox(
        "📊 Visualization Method",
        options=["Original", "Grad-CAM", "Guided Grad-CAM", "Integrated Gradients"],
        key="explain_method"
    )
    
    if method == "Original":
        if image_data['image']:
            st.image(image_data['image'], caption="Original Image", use_column_width=True)
    
    elif method == "Grad-CAM":
        # Get overlay controls
        opacity = st.session_state.get('opacity', 70)
        threshold = st.session_state.get('threshold', 0.3)
        colormap = st.session_state.get('colormap', 'jet')
        display_gradcam_visualization(image_data, opacity, threshold, colormap)
    
    elif method == "Guided Grad-CAM":
        opacity = st.session_state.get('opacity', 70)
        threshold = st.session_state.get('threshold', 0.3)
        colormap = st.session_state.get('colormap', 'jet')
        display_guided_gradcam_visualization(image_data, opacity, threshold, colormap)
    
    elif method == "Integrated Gradients":
        opacity = st.session_state.get('opacity', 70)
        threshold = st.session_state.get('threshold', 0.3)
        colormap = st.session_state.get('colormap', 'jet')
        display_integrated_gradients_visualization(image_data, opacity, threshold, colormap)
    
    # Overlay controls
    if method != "Original":
        st.subheader("🎛️ Overlay Controls")
        
        col1, col2 = st.columns(2)
        
        with col1:
            opacity = st.slider("👁️ Opacity", min_value=0, max_value=100, value=70, step=5, key='opacity')
        
        with col2:
            threshold = st.slider("🎯 Threshold", min_value=0.0, max_value=1.0, value=0.3, step=0.1, key='threshold')
        
        # Color map selection
        colormap = st.selectbox(
            "🎨 Color Map",
            options=["jet", "hot", "viridis", "plasma", "inferno"],
            index=0,
            key='colormap'
        )
        
        # Download button for explainability
        if st.button("💾 Download 3-up PNG"):
            from utils.explainability import generate_three_up_comparison
            import io
            
            # Generate comparison with current settings
            three_up_image = generate_three_up_comparison(
                image_data['image'], 
                image_data['prediction'],
                opacity / 100.0,  # Convert to 0-1 scale
                threshold,
                colormap
            )
            
            # Convert to bytes for download
            img_buffer = io.BytesIO()
            three_up_image.save(img_buffer, format='PNG')
            img_bytes = img_buffer.getvalue()
            
            st.download_button(
                label="💾 Download 3-up Comparison",
                data=img_bytes,
                file_name=f"explainability_comparison_{image_data['prediction']}.png",
                mime="image/png"
            )

def display_gradcam_visualization(image_data, opacity=70, threshold=0.3, colormap='jet'):
    """Display Grad-CAM visualization with overlay controls"""
    st.info("🔬 Generating Grad-CAM visualization...")
    
    # Generate Grad-CAM overlay with controls
    gradcam_overlay = generate_gradcam(
        image_data['image'], 
        image_data['prediction'],
        alpha=opacity / 100.0,  # Convert to 0-1 scale
        threshold=threshold,
        colormap=colormap
    )
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.image(image_data['image'], caption="Original", use_column_width=True)
    
    with col2:
        st.image(gradcam_overlay, caption="Grad-CAM Overlay", use_column_width=True)
    
    st.markdown("**Grad-CAM Interpretation:**")
    st.write("- Red/Yellow areas: High importance for AI decision")
    st.write("- Blue areas: Low importance for AI decision")
    st.write("- Focus areas indicate regions driving the prediction")

def display_guided_gradcam_visualization(image_data, opacity=70, threshold=0.3, colormap='jet'):
    """Display Guided Grad-CAM visualization with overlay controls"""
    st.info("🔬 Generating Guided Grad-CAM visualization...")
    
    guided_gradcam = generate_guided_gradcam(
        image_data['image'], 
        image_data['prediction'],
        alpha=opacity / 100.0,
        threshold=threshold,
        colormap=colormap
    )
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.image(image_data['image'], caption="Original", use_column_width=True)
    
    with col2:
        st.image(guided_gradcam, caption="Guided Grad-CAM", use_column_width=True)
    
    st.markdown("**Guided Grad-CAM Interpretation:**")
    st.write("- Combines gradient and activation information")
    st.write("- Shows specific features important for classification")
    st.write("- More precise localization than standard Grad-CAM")

def display_integrated_gradients_visualization(image_data, opacity=70, threshold=0.3, colormap='jet'):
    """Display Integrated Gradients visualization with overlay controls"""
    st.info("🔬 Generating Integrated Gradients visualization...")
    
    ig_attribution = generate_integrated_gradients(
        image_data['image'], 
        image_data['prediction'],
        alpha=opacity / 100.0,
        threshold=threshold,
        colormap=colormap
    )
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.image(image_data['image'], caption="Original", use_column_width=True)
    
    with col2:
        st.image(ig_attribution, caption="Integrated Gradients", use_column_width=True)
    
    st.markdown("**Integrated Gradients Interpretation:**")
    st.write("- Attribution map showing pixel importance")
    st.write("- Satisfies sensitivity and implementation invariance")
    st.write("- Baseline-relative feature importance")

def display_right_panel(image_data, idx):
    """Display right panel with prediction details and actions"""
    st.subheader("📊 Prediction Details")
    
    # Check if prediction has been overridden
    is_overridden = image_data.get('overridden', False)
    
    # Display override status if applicable
    if is_overridden:
        st.info("🔄 **Prediction has been manually overridden**")
        original_pred = image_data.get('original_prediction', 'Unknown')
        original_conf = image_data.get('original_confidence', 0)
        st.write(f"**Original AI Prediction:** {original_pred} ({original_conf:.1f}%)")
        st.write(f"**Override Reason:** {image_data.get('override_reason', 'Not specified')}")
        if image_data.get('override_notes'):
            st.write(f"**Override Notes:** {image_data.get('override_notes')}")
        st.markdown("---")
    
    # Prediction confidence visualization
    prediction = image_data['prediction']
    confidence = image_data['confidence']
    
    # Confidence bar chart
    fig = go.Figure(go.Bar(
        x=[confidence, 100-confidence],
        y=[prediction, 'Other'],
        orientation='h',
        marker_color=['#42A784' if prediction == 'Normal' else '#D64545', '#E5E5E5']
    ))
    
    fig.update_layout(
        title="Confidence Score",
        xaxis_title="Confidence (%)",
        height=200,
        showlegend=False
    )
    
    st.plotly_chart(fig, use_container_width=True)
    
    # Referral recommendation
    st.subheader("🏥 Referral Recommendation")
    referral = image_data['referral']
    
    if referral == 'Urgent':
        st.error(f"🚨 **{referral}** - Immediate specialist consultation recommended")
    elif referral == 'Routine':
        st.warning(f"⚠️ **{referral}** - Schedule specialist follow-up")
    else:
        st.success(f"✅ **{referral}** - Continue routine screening")
    
    # Quality control status
    st.subheader("✅ Quality Control")
    qc_flags = image_data['qc_flags']
    
    for flag, status in qc_flags.items():
        icon = "✅" if status else "❌"
        color = "green" if status else "red"
        # Use safer text display for QC flags
        if status:
            st.success(f"{icon} {flag}")
        else:
            st.error(f"{icon} {flag}")
    
    # Clinician notes
    st.subheader("📝 Clinician Notes")
    notes = st.text_area(
        "Add notes...",
        value=image_data.get('notes', ''),
        height=100,
        key=f"notes_{idx}"
    )
    
    # Update notes in session state
    st.session_state.processed_images[idx]['notes'] = notes
    
    # Action buttons
    st.subheader("🔧 Actions")
    
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("✅ Mark Reviewed", use_container_width=True):
            st.session_state.processed_images[idx]['reviewed'] = True
            st.success("✅ Marked as reviewed")
            st.rerun()
    
    with col2:
        if st.button("🔄 Override Prediction", use_container_width=True):
            show_override_modal(idx)
    
    if st.button("📄 Generate PDF Report", use_container_width=True):
        generate_individual_report(image_data, idx)
    
    if st.button("💾 Download Current Image", use_container_width=True):
        download_current_image(image_data)
    
    # Image navigation
    st.markdown("---")
    st.subheader("🧭 Navigation")
    
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("⬅️ Previous Image", use_container_width=True):
            if idx > 0:
                st.session_state.selected_image_idx = idx - 1
                st.rerun()
    
    with col2:
        if st.button("➡️ Next Image", use_container_width=True):
            if idx < len(st.session_state.processed_images) - 1:
                st.session_state.selected_image_idx = idx + 1
                st.rerun()

def show_override_modal(idx):
    """Show override prediction modal"""
    current_image = st.session_state.processed_images[idx]
    current_pred = current_image['prediction']
    
    with st.expander("🔄 Override Model Prediction", expanded=True):
        st.write(f"**Current Prediction:** {current_pred} ({current_image['confidence']:.1f}%)")
        
        # Get current override values if they exist
        current_override_reason = current_image.get('override_reason', 'Image artifact')
        current_override_notes = current_image.get('override_notes', '')
        
        new_prediction = st.selectbox(
            "New Prediction:",
            options=["ARMD", "Normal"],
            index=0 if current_pred == "ARMD" else 1,
            key=f"override_pred_{idx}",
            help="Select the correct diagnosis"
        )
        
        override_reason = st.selectbox(
            "Reason for Override:",
            options=["Image artifact", "Other disease", "Label error", "Clinical judgment", "Other"],
            index=0,  # Default to first option
            key=f"override_reason_{idx}",
            help="Why is the AI prediction being overridden?"
        )
        
        additional_notes = st.text_area(
            "Additional Notes:",
            value=current_override_notes,
            key=f"override_notes_{idx}",
            height=80,
            help="Optional additional details about the override decision"
        )
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            if st.button("💾 Save Override", key=f"save_override_{idx}"):
                # Store original prediction if not already overridden
                if not current_image.get('overridden', False):
                    st.session_state.processed_images[idx]['original_prediction'] = current_pred
                    st.session_state.processed_images[idx]['original_confidence'] = current_image['confidence']
                
                # Update with override values
                st.session_state.processed_images[idx]['prediction'] = new_prediction
                st.session_state.processed_images[idx]['override_reason'] = override_reason
                st.session_state.processed_images[idx]['override_notes'] = additional_notes
                st.session_state.processed_images[idx]['overridden'] = True
                
                # Update referral recommendation based on new prediction
                if new_prediction == 'ARMD':
                    st.session_state.processed_images[idx]['referral'] = 'Urgent'
                else:
                    st.session_state.processed_images[idx]['referral'] = 'No Referral'
                
                st.success("🔄 Prediction override saved successfully!")
                st.rerun()
        
        with col2:
            if current_image.get('overridden', False):
                if st.button("↩️ Restore Original", key=f"restore_override_{idx}"):
                    # Restore original prediction
                    original_pred = current_image.get('original_prediction', current_pred)
                    original_conf = current_image.get('original_confidence', current_image['confidence'])
                    
                    st.session_state.processed_images[idx]['prediction'] = original_pred
                    st.session_state.processed_images[idx]['confidence'] = original_conf
                    st.session_state.processed_images[idx]['overridden'] = False
                    
                    # Remove override-specific fields
                    for key in ['override_reason', 'override_notes', 'original_prediction', 'original_confidence']:
                        st.session_state.processed_images[idx].pop(key, None)
                    
                    # Restore original referral
                    if original_pred == 'ARMD':
                        st.session_state.processed_images[idx]['referral'] = 'Urgent'
                    else:
                        st.session_state.processed_images[idx]['referral'] = 'No Referral'
                    
                    st.success("↩️ Original prediction restored")
                    st.rerun()
        
        with col3:
            if st.button("❌ Cancel", key=f"cancel_override_{idx}"):
                st.info("❌ Override cancelled")

def generate_individual_report(image_data, idx):
    """Generate PDF report for individual image"""
    try:
        # Generate patient info if available
        patient_info = {
            'id': image_data.get('patient_id', f"PAT-{idx+1:04d}"),
            'name': f"Patient {idx+1:04d}",
            'age': 'N/A',
            'eye': 'N/A'
        }
        
        # Generate PDF using the utility function
        from utils.pdf_generator import generate_single_image_report
        from datetime import datetime
        
        pdf_data = generate_single_image_report(image_data, patient_info)
        
        # Generate filename with timestamp
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"amd_report_{image_data['filename'].split('.')[0]}_{timestamp}.pdf"
        
        # Show download button
        st.download_button(
            label="📄 Download Individual Report (PDF)",
            data=pdf_data,
            file_name=filename,
            mime="application/pdf",
            use_container_width=True
        )
        
        st.success("📄 Individual PDF report generated successfully!")
        
    except Exception as e:
        st.error(f"❌ Report generation failed: {str(e)}")

def download_current_image(image_data):
    """Download current image as JPEG"""
    try:
        import io
        from PIL import Image
        
        image = image_data['image']
        if image is None:
            st.error("❌ No image available for download")
            return
        
        # Convert image to bytes
        img_buffer = io.BytesIO()
        
        # Ensure RGB mode for JPEG
        if image.mode != 'RGB':
            image = image.convert('RGB')
        
        image.save(img_buffer, format='JPEG', quality=95)
        img_bytes = img_buffer.getvalue()
        
        # Generate filename
        from datetime import datetime
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        original_name = image_data['filename'].split('.')[0]
        filename = f"amd_image_{original_name}_{timestamp}.jpg"
        
        # Show download button
        st.download_button(
            label="💾 Download Current Image (JPEG)",
            data=img_bytes,
            file_name=filename,
            mime="image/jpeg",
            use_container_width=True
        )
        
        st.success("💾 Image ready for download!")
        
    except Exception as e:
        st.error(f"❌ Image download failed: {str(e)}")

if __name__ == "__main__":
    main()
