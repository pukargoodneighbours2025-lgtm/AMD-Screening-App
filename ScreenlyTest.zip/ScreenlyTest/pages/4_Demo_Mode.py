import streamlit as st
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageEnhance, ImageFilter
import io
import base64
from datetime import datetime
from utils.ai_simulation import simulate_amd_prediction
from utils.image_processing import validate_image_quality

st.set_page_config(page_title="Demo Mode", page_icon="🎮", layout="wide")

def main():
    st.title("🎮 Demo Mode")
    
    # Navigation
    col1, col2 = st.columns([1, 4])
    with col1:
        if st.button("← Back to Dashboard"):
            st.switch_page("app.py")
    
    st.markdown("---")
    
    st.markdown("""
    **🎯 Welcome to AMD Screening Demo**
    
    Explore the AI-powered screening system with pre-selected sample cases that demonstrate different scenarios:
    - **Good Cases**: Clear, high-quality images with confident predictions
    - **Hard Cases**: Challenging cases that require careful interpretation
    - **Failure Cases**: Examples of quality issues and system limitations
    """)
    
    # Demo case selection
    st.subheader("📋 Select Demo Case Category")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("### ✅ Good Cases")
        st.markdown("High-quality images with clear diagnoses")
        if st.button("🔍 Load Good Cases", use_container_width=True):
            load_demo_cases("good")
    
    with col2:
        st.markdown("### ⚠️ Hard Cases") 
        st.markdown("Challenging cases requiring expert review")
        if st.button("🔍 Load Hard Cases", use_container_width=True):
            load_demo_cases("hard")
    
    with col3:
        st.markdown("### ❌ Failure Cases")
        st.markdown("Quality issues and system limitations")
        if st.button("🔍 Load Failure Cases", use_container_width=True):
            load_demo_cases("failure")
    
    # Display loaded demo cases
    if 'demo_cases' in st.session_state and st.session_state.demo_cases:
        display_demo_cases()
    
    # Educational content
    st.markdown("---")
    display_educational_content()

def load_demo_cases(case_type):
    """Load demo cases based on type"""
    st.session_state.demo_cases = []
    st.session_state.demo_case_type = case_type
    
    if case_type == "good":
        cases = generate_good_cases()
    elif case_type == "hard":
        cases = generate_hard_cases()
    else:  # failure
        cases = generate_failure_cases()
    
    # Process each demo case
    for case in cases:
        # Simulate processing
        processed_case = process_demo_case(case)
        st.session_state.demo_cases.append(processed_case)
    
    # Also add to processed images for global access
    if 'processed_images' not in st.session_state:
        st.session_state.processed_images = []
    
    st.session_state.processed_images.extend(st.session_state.demo_cases)
    
    st.success(f"✅ Loaded {len(cases)} {case_type} demo cases")
    st.rerun()

def generate_good_cases():
    """Generate good quality demo cases"""
    cases = [
        {
            "filename": "normal_macula_001.jpg",
            "case_description": "High-quality normal macula, well-centered",
            "expected_prediction": "Normal",
            "expected_confidence": 94.2,
            "quality_issues": None
        },
        {
            "filename": "amd_severe_002.jpg", 
            "case_description": "Clear AMD with drusen, excellent image quality",
            "expected_prediction": "ARMD",
            "expected_confidence": 91.8,
            "quality_issues": None
        },
        {
            "filename": "normal_healthy_003.jpg",
            "case_description": "Healthy retina, optimal lighting and focus",
            "expected_prediction": "Normal", 
            "expected_confidence": 96.5,
            "quality_issues": None
        }
    ]
    return cases

def generate_hard_cases():
    """Generate challenging demo cases"""
    cases = [
        {
            "filename": "borderline_amd_001.jpg",
            "case_description": "Early AMD changes, requires expert interpretation",
            "expected_prediction": "ARMD",
            "expected_confidence": 67.3,
            "quality_issues": None
        },
        {
            "filename": "ambiguous_drusen_002.jpg",
            "case_description": "Ambiguous drusen pattern, low confidence",
            "expected_prediction": "Normal",
            "expected_confidence": 54.8,
            "quality_issues": None
        },
        {
            "filename": "other_pathology_003.jpg",
            "case_description": "Other retinal pathology mimicking AMD",
            "expected_prediction": "ARMD",
            "expected_confidence": 62.1,
            "quality_issues": None
        }
    ]
    return cases

def generate_failure_cases():
    """Generate failure/quality issue demo cases"""
    cases = [
        {
            "filename": "blurry_image_001.jpg",
            "case_description": "Severe motion blur affecting diagnosis",
            "expected_prediction": "Normal",
            "expected_confidence": 45.2,
            "quality_issues": ["blur", "focus"]
        },
        {
            "filename": "poor_lighting_002.jpg",
            "case_description": "Overexposed image with glare artifacts",
            "expected_prediction": "ARMD",
            "expected_confidence": 38.7,
            "quality_issues": ["illumination", "glare"]
        },
        {
            "filename": "off_center_003.jpg",
            "case_description": "Macula not properly centered in frame",
            "expected_prediction": "Normal",
            "expected_confidence": 41.5,
            "quality_issues": ["centering", "cropping"]
        }
    ]
    return cases

def process_demo_case(case):
    """Process a demo case and generate synthetic results"""
    # Create a synthetic retinal image
    synthetic_image = create_synthetic_retinal_image(case)
    
    # Simulate quality control
    qc_flags = {
        "Blur": case["quality_issues"] is None or "blur" not in case["quality_issues"],
        "Illumination": case["quality_issues"] is None or "illumination" not in case["quality_issues"], 
        "Centered": case["quality_issues"] is None or "centering" not in case["quality_issues"],
        "Macula Visible": case["quality_issues"] is None or "cropping" not in case["quality_issues"]
    }
    
    # Determine referral based on prediction and confidence
    if case["expected_prediction"] == "ARMD":
        if case["expected_confidence"] > 80:
            referral = "Urgent"
        else:
            referral = "Routine"
    else:
        referral = "No Referral"
    
    # Create processed case
    processed_case = {
        'filename': case["filename"],
        'image': synthetic_image,
        'prediction': case["expected_prediction"],
        'confidence': case["expected_confidence"],
        'referral': referral,
        'qc_flags': qc_flags,
        'case_description': case["case_description"],
        'upload_time': datetime.now(),
        'notes': f"Demo case: {case['case_description']}",
        'reviewed': False,
        'demo_case': True
    }
    
    return processed_case

def create_synthetic_retinal_image(case):
    """Create a synthetic retinal image for demo purposes"""
    # Create a 512x512 image
    width, height = 512, 512
    
    # Base colors for retinal image
    if "normal" in case["filename"].lower():
        base_color = (200, 120, 80)  # Normal retinal color
    else:
        base_color = (180, 100, 60)  # Slightly different for AMD
    
    # Create image with gradient background
    image = Image.new('RGB', (width, height), base_color)
    draw = ImageDraw.Draw(image)
    
    # Add circular retinal pattern
    center_x, center_y = width // 2, height // 2
    
    # Draw optic disc
    disc_x, disc_y = center_x + 100, center_y - 50
    draw.ellipse([disc_x-30, disc_y-30, disc_x+30, disc_y+30], fill=(255, 220, 180))
    
    # Draw blood vessels
    for i in range(8):
        angle = i * 45
        end_x = center_x + int(200 * np.cos(np.radians(angle)))
        end_y = center_y + int(200 * np.sin(np.radians(angle)))
        draw.line([disc_x, disc_y, end_x, end_y], fill=(120, 40, 40), width=3)
    
    # Add pathology markers for AMD cases
    if "amd" in case["filename"].lower():
        # Add drusen-like spots
        for i in range(5):
            spot_x = center_x + np.random.randint(-80, 80)
            spot_y = center_y + np.random.randint(-80, 80)
            spot_size = np.random.randint(5, 15)
            draw.ellipse([spot_x-spot_size, spot_y-spot_size, 
                         spot_x+spot_size, spot_y+spot_size], 
                        fill=(255, 255, 200))
    
    # Apply quality degradation for failure cases
    if case["quality_issues"]:
        if "blur" in case["quality_issues"]:
            # Simulate blur (simplified)
            image = image.filter(ImageFilter.BLUR)
        
        if "illumination" in case["quality_issues"]:
            # Increase brightness to simulate overexposure
            enhancer = ImageEnhance.Brightness(image)
            image = enhancer.enhance(1.8)
    
    # Add case identifier text
    draw.text((10, 10), f"DEMO: {case['filename']}", fill=(255, 255, 255))
    
    return image

def display_demo_cases():
    """Display loaded demo cases"""
    st.subheader(f"📋 {st.session_state.demo_case_type.title()} Demo Cases")
    
    # Summary metrics for demo cases
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Cases Loaded", len(st.session_state.demo_cases))
    
    with col2:
        amd_cases = len([c for c in st.session_state.demo_cases if c['prediction'] == 'ARMD'])
        st.metric("AMD Cases", amd_cases)
    
    with col3:
        avg_conf = np.mean([c['confidence'] for c in st.session_state.demo_cases])
        st.metric("Avg Confidence", f"{avg_conf:.1f}%")
    
    # Display individual cases
    for i, case in enumerate(st.session_state.demo_cases):
        with st.expander(f"📸 {case['filename']}", expanded=True):
            col1, col2 = st.columns([1, 2])
            
            with col1:
                st.image(case['image'], caption=case['filename'], width=200)
            
            with col2:
                st.markdown(f"**Description:** {case['case_description']}")
                
                # Prediction with color coding
                pred_color = "#D64545" if case['prediction'] == 'ARMD' else "#42A784"
                st.markdown(f"**Prediction:** <span style='color: {pred_color};'>{case['prediction']}</span>", unsafe_allow_html=True)
                
                st.metric("Confidence", f"{case['confidence']:.1f}%")
                
                # Referral recommendation
                if case['referral'] == 'Urgent':
                    st.error(f"🚨 {case['referral']}")
                elif case['referral'] == 'Routine':
                    st.warning(f"⚠️ {case['referral']}")
                else:
                    st.success(f"✅ {case['referral']}")
                
                # Quality flags
                st.markdown("**Quality Assessment:**")
                for flag, status in case['qc_flags'].items():
                    icon = "✅" if status else "❌"
                    st.markdown(f"- {icon} {flag}")
                
                # Action buttons
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    if st.button(f"🔍 View Details", key=f"view_demo_{i}"):
                        # Find the index in the global processed images
                        global_idx = len(st.session_state.processed_images) - len(st.session_state.demo_cases) + i
                        st.session_state.selected_image_idx = global_idx
                        st.switch_page("pages/3_Image_Viewer.py")
                
                with col2:
                    if st.button(f"📊 Explain", key=f"explain_demo_{i}"):
                        st.info("🔬 Explainability view available in Image Viewer")
                
                with col3:
                    if st.button(f"📄 Report", key=f"report_demo_{i}"):
                        st.success("📋 Added to report queue")
    
    # Batch actions for demo cases
    st.markdown("---")
    st.subheader("🔧 Demo Actions")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("📊 View All in Batch Results"):
            st.switch_page("pages/2_Batch_Results.py")
    
    with col2:
        if st.button("📄 Generate Demo Report"):
            st.success("📋 Demo report generation started")
    
    with col3:
        if st.button("🔄 Load Different Cases"):
            if 'demo_cases' in st.session_state:
                del st.session_state.demo_cases
            if 'demo_case_type' in st.session_state:
                del st.session_state.demo_case_type
            st.rerun()

def display_educational_content():
    """Display educational content about AMD screening"""
    st.subheader("📚 Learning Resources")
    
    tab1, tab2, tab3 = st.tabs(["🔬 About AMD", "🤖 AI Model Info", "💡 Best Practices"])
    
    with tab1:
        st.markdown("""
        **Age-related Macular Degeneration (AMD)**
        
        AMD is a leading cause of vision loss in people aged 50 and older. It affects the macula, 
        the part of the eye needed for sharp, central vision.
        
        **Key Features:**
        - 🔴 **Drusen**: Yellow deposits under the retina
        - 🔴 **Pigmentary changes**: Alterations in retinal pigment
        - 🔴 **Geographic atrophy**: Advanced dry AMD
        - 🔴 **Neovascularization**: Wet AMD with abnormal blood vessels
        
        **Risk Factors:**
        - Age (50+ years)
        - Family history
        - Smoking
        - Cardiovascular disease
        """)
    
    with tab2:
        st.markdown("""
        **AI Model Information**
        
        Our AMD screening system uses deep learning to analyze fundus images:
        
        **Model Architecture:**
        - Convolutional Neural Network (CNN)
        - Trained on 50,000+ expert-labeled images
        - Validation accuracy: 94.2%
        - Sensitivity: 92.1% | Specificity: 96.3%
        
        **Explainability Methods:**
        - 🔬 **Grad-CAM**: Shows activation regions
        - 🔬 **Guided Grad-CAM**: Precise feature localization  
        - 🔬 **Integrated Gradients**: Attribution analysis
        
        **Clinical Validation:**
        - Tested on 5,000 independent cases
        - Comparable to retinal specialist performance
        - FDA submission in progress
        """)
    
    with tab3:
        st.markdown("""
        **Image Quality Best Practices**
        
        **✅ Good Image Characteristics:**
        - Macula centered in the frame
        - Clear focus with sharp details
        - Proper illumination without glare
        - Minimal patient movement artifacts
        
        **❌ Common Quality Issues:**
        - Blurred or out-of-focus images
        - Overexposed or underexposed lighting
        - Off-center macula positioning
        - Eyelid or eyelash obstruction
        
        **📸 Capture Tips:**
        - Ensure patient cooperation and fixation
        - Use consistent lighting conditions
        - Check image quality before saving
        - Retake if quality flags are triggered
        
        **🔄 When to Override AI:**
        - Clear image artifacts affecting analysis
        - Other pathology mimicking AMD
        - Clinical context suggests different diagnosis
        - Quality issues not detected by system
        """)

if __name__ == "__main__":
    main()
