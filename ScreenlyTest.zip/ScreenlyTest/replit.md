# Overview

An AI-powered Age-related Macular Degeneration (AMD) screening dashboard built with Streamlit. This medical imaging application provides automated retinal image analysis, quality control validation, and clinical decision support for ophthalmologists and healthcare providers. The system processes retinal fundus images to detect signs of AMD and provides confidence scores, referral recommendations, and explainable AI visualizations.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: Streamlit multi-page application with custom CSS styling
- **UI Components**: Dashboard tiles, image viewers, batch processing tables, and interactive charts
- **Navigation**: Page-based routing with session state management for data persistence
- **Visualization**: Plotly for charts and metrics, PIL for image processing and display

## Application Structure
- **Main Dashboard** (`app.py`): Central hub displaying daily metrics, processed image counts, and quick actions
- **Image Upload** (`pages/1_Upload_Images.py`): Multi-modal image input supporting file upload, camera capture, and ZIP archives
- **Batch Results** (`pages/2_Batch_Results.py`): Tabular view of processed images with filtering, sorting, and bulk actions
- **Image Viewer** (`pages/3_Image_Viewer.py`): Detailed single-image analysis with explainability overlays
- **Demo Mode** (`pages/4_Demo_Mode.py`): Curated sample cases for system demonstration

## AI Processing Pipeline
- **Image Quality Control**: Automated validation for blur, illumination, centering, and macula visibility
- **AMD Prediction**: Simulated deep learning model providing binary classification (ARMD/Normal) with confidence scores
- **Explainable AI**: Multiple visualization techniques including Grad-CAM, Guided Grad-CAM, and Integrated Gradients
- **Clinical Decision Support**: Automated referral recommendations based on prediction confidence and clinical rules

## Data Management
- **Session State**: Streamlit session management for temporary data persistence during user sessions
- **Image Processing**: PIL and OpenCV for image manipulation, quality assessment, and preprocessing
- **Export Capabilities**: PDF report generation for individual cases and batch summaries

## Quality Control System
- **Multi-factor Validation**: Automated checks for image quality, proper centering, and clinical suitability
- **Confidence Thresholding**: Risk-stratified recommendations based on AI confidence levels
- **Manual Override**: Clinician notes and manual review capabilities for complex cases

# External Dependencies

## Core Frameworks
- **Streamlit**: Web application framework for rapid medical dashboard development
- **Plotly**: Interactive data visualization and charting library
- **PIL (Pillow)**: Python imaging library for medical image processing

## Image Processing
- **OpenCV**: Computer vision library for advanced image analysis and quality control
- **NumPy**: Numerical computing for image array manipulation and statistical analysis
- **Matplotlib**: Additional plotting capabilities for explainability visualizations

## Document Generation
- **ReportLab**: PDF generation library for clinical reports and batch summaries
- **Base64**: Image encoding for data transfer and storage

## Simulation Components
- **Random/NumPy**: Statistical simulation of AI model predictions and daily metrics for demonstration purposes

Note: The current implementation uses simulated AI predictions for demonstration. In production deployment, this would integrate with trained deep learning models (likely TensorFlow/PyTorch) and potentially cloud-based medical imaging APIs for real AMD detection.