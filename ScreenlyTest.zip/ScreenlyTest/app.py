import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import plotly.express as px
import plotly.graph_objects as go
from utils.ai_simulation import simulate_daily_metrics

# Page configuration
st.set_page_config(
    page_title="AMD Screening Dashboard",
    page_icon="👁️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize session state
if 'processed_images' not in st.session_state:
    st.session_state.processed_images = []
if 'daily_metrics' not in st.session_state:
    st.session_state.daily_metrics = simulate_daily_metrics()

# Custom CSS for styling
st.markdown("""
<style>
.metric-card {
    background: white;
    padding: 1rem;
    border-radius: 0.5rem;
    border: 1px solid #e1e5e9;
    margin-bottom: 1rem;
}
.urgent { color: #D64545; }
.review { color: #F1C232; }
.normal { color: #42A784; }
.status-badge {
    padding: 0.2rem 0.5rem;
    border-radius: 0.25rem;
    font-size: 0.75rem;
    font-weight: bold;
}
.urgent-badge { background-color: #D64545; color: white; }
.review-badge { background-color: #F1C232; color: black; }
.normal-badge { background-color: #42A784; color: white; }
</style>
""", unsafe_allow_html=True)

def main():
    st.title("🔬 AMD Screening Dashboard")
    
    # Sidebar navigation
    st.sidebar.title("Navigation")
    st.sidebar.markdown("---")
    
    # Main dashboard content
    col1, col2, col3, col4 = st.columns(4)
    
    metrics = st.session_state.daily_metrics
    
    with col1:
        st.metric(
            label="📊 Processed Today",
            value=metrics['processed_today'],
            delta=f"+{metrics['processed_today'] - metrics['processed_yesterday']}"
        )
    
    with col2:
        st.metric(
            label="🚨 Urgent Referrals",
            value=metrics['urgent_referrals'],
            delta=f"+{metrics['urgent_referrals'] - metrics['urgent_yesterday']}"
        )
    
    with col3:
        st.metric(
            label="🎯 Avg Confidence",
            value=f"{metrics['avg_confidence']:.1f}%",
            delta=f"{metrics['confidence_change']:+.1f}%"
        )
    
    with col4:
        if metrics['last_scan']:
            st.metric(
                label="⏰ Last Scan",
                value=metrics['last_scan'].strftime("%H:%M"),
                delta=f"{(datetime.now() - metrics['last_scan']).seconds // 60} min ago"
            )
        else:
            st.metric(
                label="⏰ Last Scan",
                value="None",
                delta=None
            )
    
    st.markdown("---")
    
    # Main action buttons
    col1, col2, col3 = st.columns([2, 2, 1])
    
    with col1:
        if st.button("📤 Upload Images", type="primary", use_container_width=True):
            st.switch_page("pages/1_Upload_Images.py")
    
    with col2:
        if st.button("🎮 Run Demo", use_container_width=True):
            st.switch_page("pages/4_Demo_Mode.py")
    
    # Recent results section
    st.subheader("📋 Recent Results")
    
    if st.session_state.processed_images:
        # Display recent results table
        df = pd.DataFrame(st.session_state.processed_images)
        
        # Add status badges
        def get_status_badge(row):
            if row['referral'] == 'Urgent':
                return '🚨 Urgent'
            elif row['referral'] == 'Routine':
                return '⚠️ Review'
            else:
                return '✅ Normal'
        
        df['Status'] = df.apply(get_status_badge, axis=1)
        
        # Display simplified table
        display_df = df[['filename', 'prediction', 'confidence', 'Status']].tail(10)
        display_df.columns = ['Image', 'Prediction', 'Confidence (%)', 'Status']
        
        st.dataframe(display_df, use_container_width=True)
        
        if st.button("📊 View All Results"):
            st.switch_page("pages/2_Batch_Results.py")
    
    else:
        # Empty state
        st.info("📂 No images processed. Upload images or run demo to get started.")
        
        col1, col2 = st.columns(2)
        with col1:
            if st.button("📤 Upload Your First Images", use_container_width=True):
                st.switch_page("pages/1_Upload_Images.py")
        
        with col2:
            if st.button("🎮 Try Demo Cases", use_container_width=True):
                st.switch_page("pages/4_Demo_Mode.py")
    
    # Weekly trend chart
    if st.session_state.processed_images:
        st.subheader("📈 Weekly Screening Trends")
        
        # Generate sample weekly data
        dates = [datetime.now() - timedelta(days=i) for i in range(7, 0, -1)]
        daily_counts = [len([img for img in st.session_state.processed_images 
                           if img.get('date', datetime.now()).date() == date.date()]) 
                       for date in dates]
        
        # Fill with sample data if empty
        if sum(daily_counts) == 0:
            daily_counts = [12, 8, 15, 20, 18, 25, len(st.session_state.processed_images)]
        
        fig = px.line(
            x=[d.strftime("%m/%d") for d in dates],
            y=daily_counts,
            title="Daily Screening Volume",
            labels={'x': 'Date', 'y': 'Images Processed'}
        )
        fig.update_traces(line_color='#42A784', line_width=3)
        fig.update_layout(showlegend=False)
        
        st.plotly_chart(fig, use_container_width=True)

if __name__ == "__main__":
    main()
