from reportlab.lib import colors
from reportlab.lib.pagesizes import letter, A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image as RLImage, Table, TableStyle
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
import io
import base64
from PIL import Image
from datetime import datetime, timedelta
import tempfile
import os

def generate_single_image_report(image_data, patient_info=None):
    """
    Generate PDF report for a single image analysis
    """
    buffer = io.BytesIO()
    
    # Create the PDF document
    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        rightMargin=72,
        leftMargin=72,
        topMargin=72,
        bottomMargin=18
    )
    
    # Container for the 'Flowable' objects
    elements = []
    
    # Define styles
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=18,
        textColor=colors.HexColor('#2F2F2F'),
        alignment=TA_CENTER,
        spaceAfter=30
    )
    
    # Add header
    elements.append(Paragraph("AMD Screening Report", title_style))
    elements.append(Spacer(1, 12))
    
    # Patient information
    if patient_info:
        patient_table_data = [
            ['Patient ID:', patient_info.get('id', 'N/A')],
            ['Name:', patient_info.get('name', 'N/A')],
            ['Age:', patient_info.get('age', 'N/A')],
            ['Eye:', patient_info.get('eye', 'N/A')],
            ['Date:', datetime.now().strftime('%Y-%m-%d %H:%M')]
        ]
    else:
        patient_table_data = [
            ['Image:', image_data['filename']],
            ['Date:', datetime.now().strftime('%Y-%m-%d %H:%M')],
            ['Analysis ID:', f"AMD_{datetime.now().strftime('%Y%m%d_%H%M%S')}"]
        ]
    
    patient_table = Table(patient_table_data, colWidths=[2*inch, 3*inch])
    patient_table.setStyle(TableStyle([
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ]))
    
    elements.append(patient_table)
    elements.append(Spacer(1, 20))
    
    # Add image if available
    if image_data.get('image'):
        # Save image temporarily
        temp_image_path = save_temp_image(image_data['image'])
        if temp_image_path:
            # Add image to PDF
            img = RLImage(temp_image_path, width=4*inch, height=3*inch)
            img.hAlign = 'CENTER'
            elements.append(img)
            elements.append(Spacer(1, 20))
            
            # Clean up temp file
            try:
                os.unlink(temp_image_path)
            except:
                pass
    
    # Prediction results
    prediction = image_data['prediction']
    confidence = image_data['confidence']
    referral = image_data['referral']
    
    # Color code based on prediction
    if prediction == 'ARMD':
        pred_color = colors.HexColor('#D64545')
    else:
        pred_color = colors.HexColor('#42A784')
    
    prediction_style = ParagraphStyle(
        'PredictionStyle',
        parent=styles['Normal'],
        fontSize=14,
        textColor=pred_color,
        fontName='Helvetica-Bold'
    )
    
    elements.append(Paragraph("Analysis Results", styles['Heading2']))
    elements.append(Spacer(1, 12))
    
    # Results table
    results_data = [
        ['AI Prediction:', f"{prediction}"],
        ['Confidence Score:', f"{confidence:.1f}%"],
        ['Referral Recommendation:', referral],
        ['Quality Control:', "Passed" if all(image_data.get('qc_flags', {}).values()) else "Failed"]
    ]
    
    results_table = Table(results_data, colWidths=[2.5*inch, 2.5*inch])
    results_table.setStyle(TableStyle([
        ('FONTSIZE', (0, 0), (-1, -1), 11),
        ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ('BACKGROUND', (0, 0), (0, -1), colors.HexColor('#F5F5F5'))
    ]))
    
    elements.append(results_table)
    elements.append(Spacer(1, 20))
    
    # Quality control details
    if 'qc_flags' in image_data:
        elements.append(Paragraph("Quality Assessment", styles['Heading3']))
        elements.append(Spacer(1, 12))
        
        qc_data = [['Quality Factor', 'Status']]
        for flag, status in image_data['qc_flags'].items():
            status_text = "✓ Pass" if status else "✗ Fail"
            qc_data.append([flag, status_text])
        
        qc_table = Table(qc_data, colWidths=[2*inch, 1.5*inch])
        qc_table.setStyle(TableStyle([
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#E5E5E5'))
        ]))
        
        elements.append(qc_table)
        elements.append(Spacer(1, 20))
    
    # Clinical notes
    notes = image_data.get('notes', '')
    if notes:
        elements.append(Paragraph("Clinical Notes", styles['Heading3']))
        elements.append(Spacer(1, 12))
        elements.append(Paragraph(notes, styles['Normal']))
        elements.append(Spacer(1, 20))
    
    # Disclaimer
    disclaimer_text = """
    <b>Important Disclaimer:</b> This AI-based screening tool is intended to assist healthcare 
    professionals and should not replace clinical judgment. All results should be reviewed by 
    qualified medical personnel before making treatment decisions.
    """
    
    disclaimer_style = ParagraphStyle(
        'Disclaimer',
        parent=styles['Normal'],
        fontSize=9,
        textColor=colors.HexColor('#666666'),
        alignment=TA_CENTER
    )
    
    elements.append(Spacer(1, 30))
    elements.append(Paragraph(disclaimer_text, disclaimer_style))
    
    # Build PDF
    doc.build(elements)
    
    # Get the value of the BytesIO buffer
    pdf_data = buffer.getvalue()
    buffer.close()
    
    return pdf_data

def generate_batch_report(images_data, summary_stats=None):
    """
    Generate PDF report for batch processing results
    """
    buffer = io.BytesIO()
    
    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        rightMargin=72,
        leftMargin=72,
        topMargin=72,
        bottomMargin=18
    )
    
    elements = []
    styles = getSampleStyleSheet()
    
    # Title
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=18,
        textColor=colors.HexColor('#2F2F2F'),
        alignment=TA_CENTER,
        spaceAfter=30
    )
    
    elements.append(Paragraph("AMD Screening Batch Report", title_style))
    elements.append(Spacer(1, 12))
    
    # Report metadata
    metadata_data = [
        ['Report Generated:', datetime.now().strftime('%Y-%m-%d %H:%M:%S')],
        ['Total Images:', str(len(images_data))],
        ['Batch ID:', f"BATCH_{datetime.now().strftime('%Y%m%d_%H%M')}"]
    ]
    
    metadata_table = Table(metadata_data, colWidths=[2*inch, 3*inch])
    metadata_table.setStyle(TableStyle([
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ]))
    
    elements.append(metadata_table)
    elements.append(Spacer(1, 20))
    
    # Summary statistics
    if summary_stats:
        elements.append(Paragraph("Summary Statistics", styles['Heading2']))
        elements.append(Spacer(1, 12))
        
        summary_data = [
            ['Metric', 'Value'],
            ['Total Images Processed', str(summary_stats.get('total_images', len(images_data)))],
            ['AMD Cases Detected', str(summary_stats.get('amd_cases', 0))],
            ['Normal Cases', str(summary_stats.get('normal_cases', 0))],
            ['Urgent Referrals', str(summary_stats.get('urgent_referrals', 0))],
            ['Average Confidence', f"{summary_stats.get('avg_confidence', 0):.1f}%"],
            ['Quality Control Pass Rate', f"{summary_stats.get('qc_pass_rate', 0):.1f}%"]
        ]
        
        summary_table = Table(summary_data, colWidths=[3*inch, 2*inch])
        summary_table.setStyle(TableStyle([
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#E5E5E5'))
        ]))
        
        elements.append(summary_table)
        elements.append(Spacer(1, 20))
    
    # Individual results table
    elements.append(Paragraph("Individual Results", styles['Heading2']))
    elements.append(Spacer(1, 12))
    
    # Prepare results data
    results_data = [['Image', 'Prediction', 'Confidence', 'Referral', 'QC Status']]
    
    for img_data in images_data:
        qc_status = "Pass" if all(img_data.get('qc_flags', {}).values()) else "Fail"
        results_data.append([
            img_data.get('filename', 'Unknown'),
            img_data.get('prediction', 'N/A'),
            f"{img_data.get('confidence', 0):.1f}%",
            img_data.get('referral', 'N/A'),
            qc_status
        ])
    
    # Create table with appropriate column widths
    results_table = Table(results_data, colWidths=[1.5*inch, 1*inch, 1*inch, 1*inch, 1*inch])
    results_table.setStyle(TableStyle([
        ('FONTSIZE', (0, 0), (-1, -1), 9),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#E5E5E5'))
    ]))
    
    elements.append(results_table)
    elements.append(Spacer(1, 30))
    
    # Add disclaimer
    disclaimer_text = """
    <b>Important:</b> This automated screening report should be reviewed by qualified 
    healthcare professionals. AI predictions are advisory and require clinical validation.
    """
    
    disclaimer_style = ParagraphStyle(
        'Disclaimer',
        parent=styles['Normal'],
        fontSize=9,
        textColor=colors.HexColor('#666666'),
        alignment=TA_CENTER
    )
    
    elements.append(Paragraph(disclaimer_text, disclaimer_style))
    
    # Build PDF
    doc.build(elements)
    
    pdf_data = buffer.getvalue()
    buffer.close()
    
    return pdf_data

def save_temp_image(pil_image):
    """
    Save PIL image to temporary file for PDF inclusion
    """
    try:
        # Create temporary file
        temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.jpg')
        temp_path = temp_file.name
        temp_file.close()
        
        # Save image
        if pil_image.mode != 'RGB':
            pil_image = pil_image.convert('RGB')
        
        pil_image.save(temp_path, 'JPEG', quality=85)
        return temp_path
    
    except Exception as e:
        print(f"Error saving temporary image: {e}")
        return None

def generate_comparison_report(current_image, previous_images, patient_info=None):
    """
    Generate comparative analysis report
    """
    buffer = io.BytesIO()
    
    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        rightMargin=72,
        leftMargin=72,
        topMargin=72,
        bottomMargin=18
    )
    
    elements = []
    styles = getSampleStyleSheet()
    
    # Title
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=18,
        textColor=colors.HexColor('#2F2F2F'),
        alignment=TA_CENTER,
        spaceAfter=30
    )
    
    elements.append(Paragraph("AMD Screening Comparison Report", title_style))
    elements.append(Spacer(1, 20))
    
    # Patient info
    if patient_info:
        patient_data = [
            ['Patient ID:', patient_info.get('id', 'N/A')],
            ['Name:', patient_info.get('name', 'N/A')],
            ['Current Visit:', datetime.now().strftime('%Y-%m-%d')],
            ['Previous Visits:', str(len(previous_images))]
        ]
        
        patient_table = Table(patient_data, colWidths=[2*inch, 3*inch])
        patient_table.setStyle(TableStyle([
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        
        elements.append(patient_table)
        elements.append(Spacer(1, 20))
    
    # Current vs Previous comparison table
    comparison_data = [['Visit', 'Date', 'Prediction', 'Confidence', 'Notes']]
    
    # Current image
    comparison_data.append([
        'Current',
        datetime.now().strftime('%Y-%m-%d'),
        current_image.get('prediction', 'N/A'),
        f"{current_image.get('confidence', 0):.1f}%",
        current_image.get('notes', 'Current visit')[:30] + '...' if len(current_image.get('notes', '')) > 30 else current_image.get('notes', 'Current visit')
    ])
    
    # Previous images (last 3)
    for i, prev_img in enumerate(previous_images[-3:]):
        visit_date = prev_img.get('date', datetime.now() - timedelta(days=30*(i+1)))
        if isinstance(visit_date, str):
            date_str = visit_date
        else:
            date_str = visit_date.strftime('%Y-%m-%d')
        
        comparison_data.append([
            f'Previous {i+1}',
            date_str,
            prev_img.get('prediction', 'N/A'),
            f"{prev_img.get('confidence', 0):.1f}%",
            prev_img.get('notes', 'Previous visit')[:30] + '...' if len(prev_img.get('notes', '')) > 30 else prev_img.get('notes', 'Previous visit')
        ])
    
    comparison_table = Table(comparison_data, colWidths=[1*inch, 1*inch, 1*inch, 1*inch, 2*inch])
    comparison_table.setStyle(TableStyle([
        ('FONTSIZE', (0, 0), (-1, -1), 9),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#E5E5E5'))
    ]))
    
    elements.append(Paragraph("Visit Comparison", styles['Heading2']))
    elements.append(Spacer(1, 12))
    elements.append(comparison_table)
    elements.append(Spacer(1, 20))
    
    # Trend analysis
    elements.append(Paragraph("Trend Analysis", styles['Heading2']))
    elements.append(Spacer(1, 12))
    
    trend_text = """
    Based on the comparison of current and previous images, the following observations are noted:
    • Prediction consistency across visits
    • Confidence score trends
    • Any detected changes in retinal appearance
    • Recommendations for follow-up frequency
    """
    
    elements.append(Paragraph(trend_text, styles['Normal']))
    elements.append(Spacer(1, 30))
    
    # Disclaimer
    disclaimer_text = """
    <b>Clinical Note:</b> This comparative analysis is automatically generated and should be 
    interpreted by qualified healthcare professionals in conjunction with clinical examination 
    and patient history.
    """
    
    disclaimer_style = ParagraphStyle(
        'Disclaimer',
        parent=styles['Normal'],
        fontSize=9,
        textColor=colors.HexColor('#666666'),
        alignment=TA_CENTER
    )
    
    elements.append(Paragraph(disclaimer_text, disclaimer_style))
    
    # Build PDF
    doc.build(elements)
    
    pdf_data = buffer.getvalue()
    buffer.close()
    
    return pdf_data

def export_csv_report(images_data):
    """
    Generate CSV export of batch results
    """
    import csv
    from io import StringIO
    
    output = StringIO()
    writer = csv.writer(output)
    
    # Header row
    writer.writerow([
        'Filename',
        'Prediction',
        'Confidence (%)',
        'Referral',
        'QC_Blur',
        'QC_Illumination', 
        'QC_Centered',
        'QC_Macula_Visible',
        'Notes',
        'Upload_Time',
        'Reviewed'
    ])
    
    # Data rows
    for img_data in images_data:
        qc_flags = img_data.get('qc_flags', {})
        writer.writerow([
            img_data.get('filename', ''),
            img_data.get('prediction', ''),
            f"{img_data.get('confidence', 0):.1f}",
            img_data.get('referral', ''),
            qc_flags.get('Blur', False),
            qc_flags.get('Illumination', False),
            qc_flags.get('Centered', False),
            qc_flags.get('Macula Visible', False),
            img_data.get('notes', ''),
            img_data.get('upload_time', datetime.now()).strftime('%Y-%m-%d %H:%M:%S'),
            img_data.get('reviewed', False)
        ])
    
    csv_data = output.getvalue()
    output.close()
    
    return csv_data
