import numpy as np
import random
from datetime import datetime, timedelta
from PIL import Image

def simulate_amd_prediction(image):
    """
    Simulate AI model prediction for AMD screening
    Returns prediction results with confidence scores
    """
    # Simulate processing time
    np.random.seed(hash(str(image.size)) % 1000)
    
    # Basic image analysis to influence prediction
    img_array = np.array(image)
    
    # Calculate some basic features
    mean_brightness = np.mean(img_array)
    color_variance = np.var(img_array)
    
    # Simulate prediction logic based on image characteristics
    # This is purely for demo purposes
    
    # Base probabilities
    if mean_brightness > 150:  # Brighter images more likely normal
        base_normal_prob = 0.7
    elif mean_brightness < 80:  # Darker images might indicate pathology
        base_normal_prob = 0.4
    else:
        base_normal_prob = 0.6
    
    # Add some randomness
    random_factor = np.random.normal(0, 0.15)
    normal_prob = np.clip(base_normal_prob + random_factor, 0.1, 0.9)
    
    # Determine prediction
    if normal_prob > 0.5:
        prediction = "Normal"
        confidence = normal_prob * 100
    else:
        prediction = "ARMD" 
        confidence = (1 - normal_prob) * 100
    
    # Add some realistic confidence variation
    confidence_noise = np.random.normal(0, 5)
    confidence = np.clip(confidence + confidence_noise, 30, 99)
    
    # Determine referral recommendation
    if prediction == "ARMD":
        if confidence > 85:
            referral = "Urgent"
        elif confidence > 65:
            referral = "Routine"
        else:
            referral = "Routine"  # Still refer for expert review
    else:
        if confidence < 70:
            referral = "Routine"  # Low confidence normal should still be reviewed
        else:
            referral = "No Referral"
    
    return {
        "prediction": prediction,
        "confidence": float(confidence),
        "referral": referral,
        "processing_time": np.random.uniform(0.5, 2.0)  # Seconds
    }

def simulate_daily_metrics():
    """
    Simulate daily dashboard metrics
    """
    # Generate realistic daily metrics
    current_time = datetime.now()
    
    # Processed today
    processed_today = np.random.randint(15, 45)
    processed_yesterday = np.random.randint(10, 40)
    
    # Urgent referrals
    urgent_referrals = np.random.randint(2, 8)
    urgent_yesterday = np.random.randint(1, 6)
    
    # Average confidence
    avg_confidence = np.random.uniform(82, 95)
    confidence_change = np.random.uniform(-3, 3)
    
    # Last scan time
    minutes_ago = np.random.randint(5, 120)
    last_scan = current_time - timedelta(minutes=minutes_ago)
    
    return {
        "processed_today": processed_today,
        "processed_yesterday": processed_yesterday,
        "urgent_referrals": urgent_referrals,
        "urgent_yesterday": urgent_yesterday,
        "avg_confidence": avg_confidence,
        "confidence_change": confidence_change,
        "last_scan": last_scan
    }

def simulate_batch_processing(image_list):
    """
    Simulate batch processing of multiple images
    """
    results = []
    
    for i, image in enumerate(image_list):
        # Add some processing delay simulation
        processing_time = np.random.uniform(0.8, 1.5)
        
        # Get prediction
        prediction_result = simulate_amd_prediction(image)
        
        # Add batch-specific metadata
        result = {
            **prediction_result,
            "batch_id": f"BATCH_{datetime.now().strftime('%Y%m%d_%H%M')}",
            "image_index": i,
            "processing_order": i + 1
        }
        
        results.append(result)
    
    return results

def simulate_model_explanation(image, prediction):
    """
    Simulate explainability analysis for the AI model
    Returns explanation metadata
    """
    explanation = {
        "grad_cam_available": True,
        "guided_gradcam_available": True,
        "integrated_gradients_available": True,
        "attention_maps_available": False,
        "feature_importance": generate_feature_importance(),
        "region_analysis": generate_region_analysis(prediction),
        "confidence_breakdown": generate_confidence_breakdown(prediction)
    }
    
    return explanation

def generate_feature_importance():
    """Generate simulated feature importance scores"""
    features = [
        "Drusen patterns",
        "Pigment changes", 
        "Blood vessel characteristics",
        "Macula texture",
        "Retinal thickness",
        "Color distribution",
        "Edge sharpness",
        "Symmetry patterns"
    ]
    
    # Generate random importance scores
    importance_scores = {}
    for feature in features:
        importance_scores[feature] = np.random.uniform(0.1, 1.0)
    
    # Normalize scores
    total_importance = sum(importance_scores.values())
    for feature in importance_scores:
        importance_scores[feature] = importance_scores[feature] / total_importance
    
    return importance_scores

def generate_region_analysis(prediction):
    """Generate region-based analysis"""
    regions = {
        "macula": {
            "importance": np.random.uniform(0.7, 0.95),
            "abnormality_score": np.random.uniform(0.1, 0.8) if prediction == "ARMD" else np.random.uniform(0.05, 0.3),
            "confidence": np.random.uniform(0.8, 0.95)
        },
        "optic_disc": {
            "importance": np.random.uniform(0.2, 0.5),
            "abnormality_score": np.random.uniform(0.05, 0.3),
            "confidence": np.random.uniform(0.7, 0.9)
        },
        "blood_vessels": {
            "importance": np.random.uniform(0.3, 0.6),
            "abnormality_score": np.random.uniform(0.1, 0.4),
            "confidence": np.random.uniform(0.6, 0.85)
        },
        "periphery": {
            "importance": np.random.uniform(0.1, 0.3),
            "abnormality_score": np.random.uniform(0.05, 0.2),
            "confidence": np.random.uniform(0.5, 0.8)
        }
    }
    
    return regions

def generate_confidence_breakdown(prediction):
    """Generate confidence score breakdown by category"""
    if prediction == "ARMD":
        breakdown = {
            "early_amd": np.random.uniform(0.2, 0.4),
            "intermediate_amd": np.random.uniform(0.3, 0.5),
            "advanced_amd": np.random.uniform(0.1, 0.3),
            "normal": np.random.uniform(0.05, 0.2)
        }
    else:
        breakdown = {
            "early_amd": np.random.uniform(0.05, 0.2),
            "intermediate_amd": np.random.uniform(0.05, 0.15),
            "advanced_amd": np.random.uniform(0.02, 0.1),
            "normal": np.random.uniform(0.6, 0.85)
        }
    
    # Normalize to sum to 1
    total = sum(breakdown.values())
    for key in breakdown:
        breakdown[key] = breakdown[key] / total
    
    return breakdown

def simulate_quality_control_analysis(image):
    """
    Simulate detailed quality control analysis
    """
    img_array = np.array(image)
    
    qc_analysis = {
        "overall_score": np.random.uniform(0.7, 0.95),
        "focus_score": np.random.uniform(0.8, 0.98),
        "illumination_score": np.random.uniform(0.75, 0.95),
        "centering_score": np.random.uniform(0.7, 0.9),
        "artifacts_detected": np.random.choice([True, False], p=[0.15, 0.85]),
        "recommended_retake": np.random.choice([True, False], p=[0.1, 0.9]),
        "quality_flags": {
            "motion_blur": np.random.choice([True, False], p=[0.1, 0.9]),
            "overexposure": np.random.choice([True, False], p=[0.08, 0.92]),
            "underexposure": np.random.choice([True, False], p=[0.05, 0.95]),
            "eyelid_obstruction": np.random.choice([True, False], p=[0.12, 0.88]),
            "reflection_artifacts": np.random.choice([True, False], p=[0.15, 0.85])
        }
    }
    
    return qc_analysis

def simulate_comparative_analysis(current_image, previous_images=None):
    """
    Simulate comparative analysis with previous scans
    """
    if not previous_images:
        return None
    
    comparison = {
        "temporal_changes": {
            "detected": np.random.choice([True, False], p=[0.3, 0.7]),
            "progression_rate": np.random.choice(["stable", "slow", "moderate", "rapid"], p=[0.6, 0.25, 0.1, 0.05]),
            "change_magnitude": np.random.uniform(0.0, 0.4)
        },
        "consistency_score": np.random.uniform(0.7, 0.95),
        "recommendation": np.random.choice([
            "Continue routine monitoring",
            "Increase monitoring frequency", 
            "Consider additional testing",
            "Urgent specialist referral"
        ], p=[0.7, 0.2, 0.08, 0.02])
    }
    
    return comparison

def simulate_uncertainty_quantification(prediction_result):
    """
    Simulate uncertainty quantification for the prediction
    """
    base_confidence = prediction_result["confidence"]
    
    uncertainty = {
        "epistemic_uncertainty": np.random.uniform(0.05, 0.2),  # Model uncertainty
        "aleatoric_uncertainty": np.random.uniform(0.1, 0.3),   # Data uncertainty
        "prediction_interval": {
            "lower": max(0, base_confidence - np.random.uniform(5, 15)),
            "upper": min(100, base_confidence + np.random.uniform(5, 15))
        },
        "reliability_score": np.random.uniform(0.8, 0.95),
        "calibration_score": np.random.uniform(0.75, 0.9)
    }
    
    return uncertainty
