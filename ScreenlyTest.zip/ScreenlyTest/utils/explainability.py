import numpy as np
from PIL import Image, ImageFilter, ImageEnhance
import matplotlib.pyplot as plt
import matplotlib.cm as cm
from matplotlib.colors import Normalize
import io

def generate_gradcam(image, prediction, alpha=0.7, threshold=0.3, colormap='jet'):
    """
    Generate Grad-CAM visualization for explainability
    This is a simplified simulation of Grad-CAM
    """
    try:
        # Convert PIL image to numpy array
        img_array = np.array(image)
        height, width = img_array.shape[:2]
        
        # Simulate attention map based on prediction
        attention_map = create_attention_map(img_array, prediction)
        
        # Apply threshold
        attention_map = np.where(attention_map >= threshold, attention_map, 0)
        
        # Apply Grad-CAM colormap
        gradcam_overlay = apply_heatmap_overlay(img_array, attention_map, alpha=alpha, colormap=colormap)
        
        return gradcam_overlay
    
    except Exception as e:
        print(f"Error generating Grad-CAM: {e}")
        return image

def generate_guided_gradcam(image, prediction, alpha=0.6, threshold=0.3, colormap='jet'):
    """
    Generate Guided Grad-CAM visualization
    """
    try:
        img_array = np.array(image)
        
        # Create more focused attention map
        attention_map = create_focused_attention_map(img_array, prediction)
        
        # Apply threshold
        attention_map = np.where(attention_map >= threshold, attention_map, 0)
        
        # Apply guided gradients effect
        guided_overlay = apply_guided_overlay(img_array, attention_map, alpha=alpha, colormap=colormap)
        
        return guided_overlay
    
    except Exception as e:
        print(f"Error generating Guided Grad-CAM: {e}")
        return image

def generate_integrated_gradients(image, prediction, alpha=0.5, threshold=0.3, colormap='jet'):
    """
    Generate Integrated Gradients visualization
    """
    try:
        img_array = np.array(image)
        
        # Create attribution map
        attribution_map = create_attribution_map(img_array, prediction)
        
        # Apply threshold
        attribution_map = np.where(attribution_map >= threshold, attribution_map, 0)
        
        # Apply attribution visualization
        ig_overlay = apply_attribution_overlay(img_array, attribution_map, alpha=alpha, colormap=colormap)
        
        return ig_overlay
    
    except Exception as e:
        print(f"Error generating Integrated Gradients: {e}")
        return image

def create_attention_map(img_array, prediction):
    """
    Create simulated attention map based on image characteristics
    """
    height, width = img_array.shape[:2]
    
    # Initialize attention map
    attention = np.zeros((height, width))
    
    # Center region (macula area) - high attention
    center_y, center_x = height // 2, width // 2
    y, x = np.ogrid[:height, :width]
    
    # Distance from center
    center_dist = np.sqrt((x - center_x)**2 + (y - center_y)**2)
    
    # Base attention pattern - higher in center
    attention = np.exp(-center_dist / (min(height, width) * 0.3))
    
    # Modify based on prediction
    if prediction == "ARMD":
        # For ARMD, focus more on central region and potential drusen areas
        # Add some random high-attention spots (simulating drusen)
        num_spots = np.random.randint(3, 8)
        for _ in range(num_spots):
            spot_y = np.random.randint(height//4, 3*height//4)
            spot_x = np.random.randint(width//4, 3*width//4)
            spot_radius = np.random.randint(20, 50)
            
            spot_dist = np.sqrt((x - spot_x)**2 + (y - spot_y)**2)
            spot_attention = np.exp(-spot_dist / spot_radius) * np.random.uniform(0.5, 1.0)
            attention = np.maximum(attention, spot_attention)
    
    else:
        # For normal, more distributed attention
        attention *= 0.7  # Lower overall attention
        
        # Add some peripheral attention
        peripheral_mask = center_dist > min(height, width) * 0.2
        attention[peripheral_mask] += np.random.uniform(0.1, 0.3, np.sum(peripheral_mask))
    
    # Add some noise for realism
    noise = np.random.normal(0, 0.1, attention.shape)
    attention = np.clip(attention + noise, 0, 1)
    
    # Smooth the attention map
    attention_pil = Image.fromarray((attention * 255).astype(np.uint8))
    attention_pil = attention_pil.filter(ImageFilter.GaussianBlur(radius=2))
    attention = np.array(attention_pil) / 255.0
    
    return attention

def create_focused_attention_map(img_array, prediction):
    """
    Create more focused attention map for Guided Grad-CAM
    """
    attention = create_attention_map(img_array, prediction)
    
    # Apply threshold to create more focused regions
    threshold = np.percentile(attention, 70)
    attention[attention < threshold] *= 0.3
    
    # Enhance high-attention regions
    attention = np.power(attention, 0.7)
    
    return attention

def create_attribution_map(img_array, prediction):
    """
    Create attribution map for Integrated Gradients
    """
    height, width = img_array.shape[:2]
    
    # Convert to grayscale for edge detection
    if len(img_array.shape) == 3:
        gray = np.dot(img_array[...,:3], [0.2989, 0.5870, 0.1140])
    else:
        gray = img_array
    
    # Calculate gradients (simulating integrated gradients)
    grad_x = np.gradient(gray, axis=1)
    grad_y = np.gradient(gray, axis=0)
    grad_magnitude = np.sqrt(grad_x**2 + grad_y**2)
    
    # Normalize attribution
    attribution = grad_magnitude / (np.max(grad_magnitude) + 1e-8)
    
    # Modify based on prediction
    if prediction == "ARMD":
        # Enhance attribution in central regions
        center_y, center_x = height // 2, width // 2
        y, x = np.ogrid[:height, :width]
        center_dist = np.sqrt((x - center_x)**2 + (y - center_y)**2)
        center_weight = np.exp(-center_dist / (min(height, width) * 0.4))
        attribution *= (1 + center_weight)
    
    # Normalize to [0, 1]
    attribution = (attribution - np.min(attribution)) / (np.max(attribution) - np.min(attribution) + 1e-8)
    
    return attribution

def apply_heatmap_overlay(img_array, attention_map, colormap='jet', alpha=0.7):
    """
    Apply heatmap overlay to image
    """
    # Create colormap
    cmap = cm.get_cmap(colormap)
    norm = Normalize(vmin=0, vmax=1)
    
    # Apply colormap to attention
    colored_attention = cmap(norm(attention_map))
    
    # Convert to RGB
    heatmap_rgb = (colored_attention[:, :, :3] * 255).astype(np.uint8)
    
    # Blend with original image
    if len(img_array.shape) == 3:
        blended = (1 - alpha) * img_array + alpha * heatmap_rgb
    else:
        # Convert grayscale to RGB for blending
        img_rgb = np.stack([img_array] * 3, axis=-1)
        blended = (1 - alpha) * img_rgb + alpha * heatmap_rgb
    
    blended = np.clip(blended, 0, 255).astype(np.uint8)
    
    return Image.fromarray(blended)

def apply_guided_overlay(img_array, attention_map, alpha=0.6, colormap='jet'):
    """
    Apply guided visualization overlay with colormap support
    """
    # Create colormap for guided visualization
    cmap = cm.get_cmap(colormap)
    norm = Normalize(vmin=0, vmax=1)
    
    # Apply colormap to attention
    colored_attention = cmap(norm(attention_map))
    
    # Convert to RGB
    overlay_rgb = (colored_attention[:, :, :3] * 255).astype(np.uint8)
    
    # Blend with original image
    if len(img_array.shape) == 3:
        blended = (1 - alpha) * img_array + alpha * overlay_rgb
    else:
        # Convert grayscale to RGB for blending
        img_rgb = np.stack([img_array] * 3, axis=-1)
        blended = (1 - alpha) * img_rgb + alpha * overlay_rgb
    
    blended = np.clip(blended, 0, 255).astype(np.uint8)
    
    return Image.fromarray(blended)

def apply_attribution_overlay(img_array, attribution_map, alpha=0.5, colormap='jet'):
    """
    Apply attribution visualization overlay
    """
    # Create colormap for attribution
    cmap = cm.get_cmap(colormap)
    norm = Normalize(vmin=0, vmax=1)
    
    # Apply colormap
    colored_attribution = cmap(norm(attribution_map))
    attribution_rgb = (colored_attribution[:, :, :3] * 255).astype(np.uint8)
    
    # Blend with original image
    if len(img_array.shape) == 3:
        blended = (1 - alpha) * img_array + alpha * attribution_rgb
    else:
        img_rgb = np.stack([img_array] * 3, axis=-1)
        blended = (1 - alpha) * img_rgb + alpha * attribution_rgb
    
    blended = np.clip(blended, 0, 255).astype(np.uint8)
    
    return Image.fromarray(blended)

def generate_three_up_comparison(image, prediction, alpha=0.7, threshold=0.3, colormap='jet'):
    """
    Generate a three-up comparison image (Original + Grad-CAM + Guided Grad-CAM)
    """
    try:
        # Generate all visualizations with settings
        original = image
        gradcam = generate_gradcam(image, prediction, alpha=alpha, threshold=threshold, colormap=colormap)
        guided_gradcam = generate_guided_gradcam(image, prediction, alpha=alpha, threshold=threshold, colormap=colormap)
        
        # Resize images to consistent size
        target_size = (300, 300)
        original_resized = original.resize(target_size)
        gradcam_resized = gradcam.resize(target_size)
        guided_resized = guided_gradcam.resize(target_size)
        
        # Create composite image
        composite_width = target_size[0] * 3 + 40  # 20px padding between images
        composite_height = target_size[1] + 80  # Space for titles
        
        composite = Image.new('RGB', (composite_width, composite_height), 'white')
        
        # Paste images
        composite.paste(original_resized, (10, 60))
        composite.paste(gradcam_resized, (target_size[0] + 20, 60))
        composite.paste(guided_resized, (target_size[0] * 2 + 30, 60))
        
        # Add titles (would need PIL font support for actual text)
        # For now, return the composite without text
        
        return composite
    
    except Exception as e:
        print(f"Error generating three-up comparison: {e}")
        return image

def calculate_attention_statistics(attention_map):
    """
    Calculate statistics about the attention map
    """
    stats = {
        'mean_attention': float(np.mean(attention_map)),
        'max_attention': float(np.max(attention_map)),
        'attention_std': float(np.std(attention_map)),
        'high_attention_percentage': float(np.sum(attention_map > 0.7) / attention_map.size * 100),
        'focused_regions': int(np.sum(attention_map > np.percentile(attention_map, 90)))
    }
    
    return stats

def generate_attention_heatmap_only(attention_map, colormap='jet'):
    """
    Generate standalone heatmap visualization
    """
    # Create colormap
    cmap = cm.get_cmap(colormap)
    norm = Normalize(vmin=0, vmax=1)
    
    # Apply colormap
    colored_attention = cmap(norm(attention_map))
    heatmap_rgb = (colored_attention[:, :, :3] * 255).astype(np.uint8)
    
    return Image.fromarray(heatmap_rgb)

def analyze_explainability_consistency(image, prediction, num_runs=5):
    """
    Analyze consistency of explainability methods across multiple runs
    """
    attention_maps = []
    
    # Generate multiple attention maps
    for _ in range(num_runs):
        attention = create_attention_map(np.array(image), prediction)
        attention_maps.append(attention)
    
    # Calculate consistency metrics
    attention_stack = np.stack(attention_maps, axis=0)
    
    consistency_metrics = {
        'mean_correlation': float(np.mean([
            np.corrcoef(attention_maps[i].flatten(), attention_maps[j].flatten())[0, 1]
            for i in range(num_runs) for j in range(i+1, num_runs)
        ])),
        'std_across_runs': float(np.mean(np.std(attention_stack, axis=0))),
        'stable_regions': float(np.sum(np.std(attention_stack, axis=0) < 0.1) / attention_stack[0].size),
        'peak_stability': float(np.std([np.max(att) for att in attention_maps]))
    }
    
    return consistency_metrics

def generate_region_based_explanation(image, prediction, regions=None):
    """
    Generate region-based explanations
    """
    if regions is None:
        # Default retinal regions
        regions = {
            'macula': {'center': (0.5, 0.5), 'radius': 0.2},
            'optic_disc': {'center': (0.3, 0.5), 'radius': 0.1},
            'superior_arcade': {'center': (0.4, 0.3), 'radius': 0.15},
            'inferior_arcade': {'center': (0.4, 0.7), 'radius': 0.15}
        }
    
    img_array = np.array(image)
    height, width = img_array.shape[:2]
    
    region_explanations = {}
    
    for region_name, region_info in regions.items():
        # Create region mask
        center_x = int(region_info['center'][0] * width)
        center_y = int(region_info['center'][1] * height)
        radius = int(region_info['radius'] * min(height, width))
        
        y, x = np.ogrid[:height, :width]
        region_mask = (x - center_x)**2 + (y - center_y)**2 <= radius**2
        
        # Calculate region-specific attention
        full_attention = create_attention_map(img_array, prediction)
        region_attention = full_attention[region_mask]
        
        region_explanations[region_name] = {
            'mean_attention': float(np.mean(region_attention)),
            'max_attention': float(np.max(region_attention)),
            'importance_score': float(np.sum(region_attention) / np.sum(region_mask)),
            'abnormality_likelihood': float(np.mean(region_attention > 0.6))
        }
    
    return region_explanations
